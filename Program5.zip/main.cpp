//Irene Le
//CS162
//February 22nd, 2022
//This progrsm allows the user to input as many athletes as they want and their information. It will also
// allow the user to edit information about the athlete if they made a mistake
// This progrma will also allow the user whether not they want to repeat the program

#include "athlete.h"

int main()
{
	char answer = 'y';
	olympics list;
//	olympics();

do{
	//Read in athletes
	list.add_athlete();

	//Read into LLL
	list.read_into_list();

	//Display all of the athletes
	list.display_athletes();

	//Display all of the athletes with the same amount of medals
	list.display_medals();

	//Allow the user to edit information about an athlete
	list.edit();

	cout << "Would you like to run the program again? ";
	cin >> answer;
	cin.ignore(100, '\n');

}while(answer == 'y' || answer == 'Y');



return 0;
}
