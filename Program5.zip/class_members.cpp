//Irene Le
//CS 162
//February 23rd, 2022
//This file is to implement the functions of the class from the header file.

#include "athlete.h"

void olympics::read_into_list()
{
	if(head == NULL)
	{
		int counter = 1;
		head = new node;
		node * current = head;
		node * temp;

		//COPY FIRST ATHLETE INTO FIRST NODE
		strcpy(head -> list.name, ptr[0].name);
		head -> list.age = ptr[0].age;
		strcpy(head -> list.sport, ptr[0].sport);
		head -> list.medals = ptr[0].medals;
		strcpy(head -> list.page, ptr[0].page);
		strcpy(head -> list.country, ptr[0].country);
		head -> list.salary = ptr[0].salary;

		head -> next = NULL;

		while(counter < num_of_athletes)
		{
			//CREATES NEW NODE
			temp = new node;

			//CONNECTS CURRENT NODE TO NEW NODE
			current -> next = temp;
			temp -> next = NULL;

			//COPIES DATA INTO NEW NODE
			strcpy(temp -> list.name, ptr[counter].name);
			temp -> list.age = ptr[counter].age;
			strcpy(temp -> list.sport, ptr[counter].sport);
			temp -> list.medals = ptr[counter].medals;
			strcpy(temp -> list.page, ptr[counter].page);
			strcpy(temp -> list.country, ptr[counter].country);
			temp -> list.salary = ptr[counter].salary;

			//MOVES TO THE NEXT NODE
			current = current -> next;
			++counter;
		}
	}

}

//CONSTRUCTOR
olympics::olympics()
{
	cout << "How many athletes would you like to input? ";
	cin >> size;
	cin.ignore(100, '\n');

	ptr = new athlete[size];
	num_of_athletes = 0;
	head = NULL;
}

//DESTRUCTOR
olympics::~olympics()
{

	if(NULL != ptr)
		delete [] ptr;
	ptr = 0;
	size = 0;
	num_of_athletes = 0;

}

//DISPLAY MEDALS
void olympics::display_medals()
{
	int temp_medals;

	cout << "What is the number of medals you are looking for? ";
	cin >> temp_medals;
	cin.ignore(100, '\n');

	cout << "The athletes with " << temp_medals << " medals are: ";
	for(int k = 0; k < num_of_athletes; ++k)
	{
		if(ptr[k].medals == temp_medals)
			cout << ptr[k].name << endl;
	}

}


//ADD AN ATHLETE
void olympics::add_athlete()
{
	char answer = 'y';

	if(num_of_athletes == size)
		return;

	for(int k = 0; k < size && 'Y' == toupper(answer); ++k)
	{
		cout << "Please enter the name: ";
		cin.get(ptr[num_of_athletes].name, NAME, '\n');
		cin.ignore(100, '\n');

		cout << "Please enter their sport: ";
		cin.get(ptr[num_of_athletes].sport, SPORT, '\n');
		cin.ignore(100, '\n');

		cout << "Please enter the age: ";
		cin >> ptr[num_of_athletes].age;
		cin.ignore(100, '\n');

		cout << "Please enter the number of medals: ";
		cin >> ptr[num_of_athletes].medals;
		cin.ignore(100, '\n');

		cout << "Please enter their Facebook page: ";
		cin.get(ptr[num_of_athletes].page, PAGE, '\n');
		cin.ignore(100, '\n');

		cout << "Please enter their country of origin: ";
		cin.get(ptr[num_of_athletes].country, COUNTRY, '\n');
		cin.ignore(100, '\n');

		cout << "Please enter their salary: ";
		cin >> ptr[num_of_athletes].salary;
		cin.ignore(100, '\n');

		cout << "Would you like to add another athlete? ";
		cin >> answer;
		cin.ignore(100, '\n');

		++num_of_athletes;
	}

}
//DISPLAY AN ATHLETE
void olympics::display_athletes()
{
	for(int k = 0; k < num_of_athletes; ++k)
	{
		cout << ptr[k].name << endl;
		cout << ptr[k].sport << endl;
		cout << ptr[k].age << endl;
		cout << ptr[k].medals << endl;
		cout << ptr[k].page << endl;
		cout << ptr[k].country << endl;
		cout << ptr[k].salary << endl;
	}

}

//EDIT AN ATHLETE
void olympics::edit()
{

	char temp_name[100];
	char temp_edit[100];

	cout << "What athlete do you want to edit? ";
	cin.get(temp_name, 100, '\n');
	cin.ignore(100,'\n');

	for(int k = 0; k < num_of_athletes; ++k)
	{
		if(strcmp(temp_name, ptr[k].name) == 0)
		{
			cout << "What would you like to edit? (name, sport, age, medals, facebook page, country, or salary). ";
			cin.get(temp_edit, 100, '\n');
			cin.ignore(100, '\n');

			if(strcmp(temp_edit, "name") == 0)
			{
				cout << "Please enter your changes: ";
				cin.get(ptr[k].name, NAME, '\n');
				cin.ignore(100, '\n');

				cout << "This athlete's name is now " << ptr[k].name << endl;
			}

			if(strcmp(temp_edit, "sport") == 0)
			{
				cout << "Please enter your changes: ";
				cin.get(ptr[k].sport, SPORT, '\n');
				cin.ignore(100, '\n');

				cout << ptr[k].name << "'s sport is now " << ptr[k].sport << endl;

			}

			if(strcmp(temp_edit, "age") == 0)
			{
				cout << "Please enter your changes: ";
				cin >> ptr[k].age;
				cin.ignore(100, '\n');

				cout << ptr[k].name << "'s age is now " << ptr[k].age << endl;

			}
			if(strcmp(temp_edit, "medals") == 0)
			{
				cout << "Please enter your changes: ";
				cin >> ptr[k].medals;
				cin.ignore(100, '\n');

				cout << ptr[k].name << " now has" << ptr[k].medals << "medals. " << endl;

			}

			if(strcmp(temp_edit, "facebook page") == 0)
			{
				cout << "Please enter your changes: ";
				cin.get(ptr[k].page, PAGE, '\n');
				cin.ignore(100, '\n');

				cout << ptr[k].name << "'s Facebook page is now " << ptr[k].page << endl;

			}

			if(strcmp(temp_edit, "country") == 0)
			{
				cout << "Please enter your changes: ";
				cin.get(ptr[k].country, COUNTRY, '\n');
				cin.ignore(100, '\n');

				cout << ptr[k].name << "'s country is now " << ptr[k].country << endl;

			}

			if(strcmp(temp_edit, "salary") == 0)
			{
				cout << "Please enter your changes: ";
				cin >> ptr[k].salary;
				cin.ignore(100, '\n');

				cout << ptr[k].name << "'s salary is now " << ptr[k].salary << endl;

			}

		}
	}

}

