//Irene Le
//CS 162
//February 23rd, 2022
//This program is designed to allow the user to input as many athletes from the olympics
//and their information and store the data into a list of athletes.

#include <iostream>
#include <cstring>
#include <cctype>

using namespace std;

const int NAME{21};
const int SPORT{21};
const int PAGE{50};
const int COUNTRY{21};

struct athlete
{
	char name[NAME];
	int age = 0;
	char sport[SPORT];
	int medals = 0;
	char page[PAGE];
	char country[COUNTRY];
	int salary = 0;

};

struct node
{
	athlete list;
	node * next;

};

class olympics
{
	public:
		olympics();
		void add_athlete();
		void display_athletes();
		void display_medals();
		void edit();
		void read_into_list();
		
		~olympics();

	private:
	//	char * athlete;
		athlete * ptr;
		int size;
		int num_of_athletes;
		node * head;

};


